//У вас есть класс который называется Device, у этого класса есть свойство company. Также имеется еще два класса: Keyboard и Mouse,
//которые наследуют от класса Device.
//
//Создайте массив, который сможет содержать в себе любые объекты типа Device, т.е. И объекты класса Keyboard и объекты класса Mouse.
//Добавьте в этот массив несколько экземпляров каждого класса.
//
//Теперь создайте еще одну небольшую иерархию классов, например родительский класс - Animal, а наследующие от него классы - Dog и Cat.
//Также создайте массив который будет содержать в себе объекты типа Animal.
//
//Создайте массив типа AnyObject и поместите в него члены двух массов путем перечисления (через циклы for)
//И затем из этого массива c помощью проверки типов вытащите объекты только класса Dog.


class Device {
    var company: String
    
    init (company: String) {
        self.company = company
    }
}

class Keyboard: Device {
    
    var type: String //Game или Office
    var color: String
    
    init (type: String, color: String, company: String) {
        self.type = type
        self.color = color
        super.init(company: company)
    }
    
}

class Mouse: Device {
    
    var type: String //Game или Office
    var color: String
    
    init (type: String, color: String, company: String) {
        self.type = type
        self.color = color
        super.init(company: company)
    }
    
}

var mouse1 = Mouse(type: "Game", color: "Black", company: "Logitec")
var mouse2 = Mouse(type: "Office", color: "White", company: "Microsoft")
var keyboard1 = Keyboard(type: "Game", color: "Orange", company: "Asus")
var keyboard2 = Keyboard(type: "Office", color: "Silver", company: "Hp")

var deviceArray = [AnyObject] ()

deviceArray.append(mouse1)
deviceArray.append(mouse2)
deviceArray.append(keyboard1)
deviceArray.append(keyboard2)

deviceArray

class Animal {
    
    var type: String
    
    init (type: String) {
        self.type = type
    }
    
}

class Dog: Animal {
    
    var color: String
    var breed: String
    
    init (color: String, breed: String, type: String) {
        self.color = color
        self.breed = breed
        super.init(type: type)
    }
}

class Cat: Animal {
    var color: String
    var breed: String
    
    init (color: String, breed: String, type: String) {
        self.color = color
        self.breed = breed
        super.init(type: type)
    }
}

var dog1 = Dog(color: "Black", breed: "Dachshund", type: "Predator")
var dog2 = Dog(color: "Brown", breed: "Sheepdog", type: "Predator")
var cat1 = Cat(color: "White", breed: "Persian", type: "Predator")
var cat2 = Cat(color: "Gray", breed: "Russian blue", type: "Predator")

var animalArray = [AnyObject] ()

animalArray.append(dog1)
animalArray.append(dog2)
animalArray.append(cat1)
animalArray.append(cat2)

var generalArray = [AnyObject] ()

var i: Int

for i in deviceArray {
    generalArray.append(i)
}

var a: Int

for a in animalArray {
    generalArray.append(a)
}

var d: Int
var array = [AnyObject] ()

for item in generalArray {
    
    if item is Dog {
        array.append(item)
    }
}

array
