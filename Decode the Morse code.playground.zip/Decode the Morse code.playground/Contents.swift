import UIKit

func decodeMorse(_ morseCode: String) -> String {
    
    var countOfWhitespace = 0
    var countOfWord = 0
    var letter = ""
    var word = ""
    var wordCombination = ""
    var countOfCharacters = 0
    var whitespace = false
    var arrayMorseCode = [String]()
    var arrayMorseCodeToOneString = ""
    
    func  calculatingTheLetter(_ letter: String) {
        
        switch letter {
        case ".-":
            word += "A"
        case "-...":
            word += "B"
        case ".--":
            word += "W"
        case "--.":
            word += "G"
        case "-..":
            word += "D"
        case ".":
            word += "E"
        case "...-":
            word += "V"
        case "--..":
            word += "Z"
        case "..":
            word += "I"
        case ".---":
            word += "J"
        case "-.-":
            word += "K"
        case ".-..":
            word += "L"
        case "--":
            word += "M"
        case "-.":
            word += "N"
        case "---":
            word += "O"
        case ".--.":
            word += "P"
        case ".-.":
            word += "R"
        case "...":
            word += "S"
        case "-":
            word += "T"
        case "..-":
            word += "U"
        case "..-.":
            word += "F"
        case "....":
            word += "H"
        case "-.-.":
            word += "C"
        case "--.-":
            word += "Q"
        case "-.--":
            word += "Y"
        case "-..-":
            word += "X"
        case ".----":
            word += "1"
        case "..---":
            word += "2"
        case "...--":
            word += "3"
        case "....-":
            word += "4"
        case ".....":
            word += "5"
        case "-....":
            word += "6"
        case "--...":
            word += "7"
        case "---..":
            word += "8"
        case "----.":
            word += "9"
        case "-----":
            word += "0"
        case "...---...":
            word += "SOS"
        case "-.-.--":
            word += "!"
        case ".-.-.-":
            word += "."
        default:
            print("Символ не распознан")
        }
    }
    
    func addWord () {
        
        if countOfWord == 0 {
            wordCombination += word
            countOfWord = 1
            whitespace = false
        } else if countOfWord == 1 {
            wordCombination += " " + word
            whitespace = false
        }
        
    }
    
    for item in morseCode {
        
        let itemToStr = String(item)
        arrayMorseCode.append(itemToStr)
    }
    
    if arrayMorseCode.first == " " {
        while arrayMorseCode.first == " "  {
            arrayMorseCode.removeFirst()
        }
    }
    
    if arrayMorseCode.last == " " {
        while arrayMorseCode.last == " "  {
            arrayMorseCode.removeLast()
        }
    }
    
    arrayMorseCodeToOneString = arrayMorseCode.joined(separator: "")
    
    let numberOfCharacters = arrayMorseCodeToOneString.count
    
    for item in arrayMorseCodeToOneString {

        countOfCharacters += 1

        if item == " " {

            countOfWhitespace += 1
        }

        if item != " " && countOfWhitespace == 0 {

            let itemToStr = String(item)
            letter += itemToStr
        }

        if item != " " && countOfWhitespace == 3 {
            whitespace = true
        }

        if item != " " && countOfWhitespace == 1 || whitespace == true {
            
            calculatingTheLetter(letter)

            let itemToStr = String(item)
            letter = itemToStr
            
            countOfWhitespace = 0
        }
        
        if countOfCharacters == numberOfCharacters {
            
            if whitespace == true {
                addWord()
                countOfWhitespace = 0
                word = ""
                calculatingTheLetter(letter)
            } else {
                calculatingTheLetter(letter)
            }
        }

        if whitespace == true || countOfCharacters == numberOfCharacters {

            addWord()

            countOfWhitespace = 0
            word = ""
        }

    }

    return wordCombination
}

decodeMorse("      ...---... -.-.--   - .... .   --.- ..- .. -.-. -.-   -... .-. --- .-- -.   ..-. --- -..-   .--- ..- -- .--. ...   --- ...- . .-.   - .... .   .-.. .- --.. -.--   -.. --- --. .-.-.-  ")
