//Используя протоколы написать программу «Ферма». Задача: программа «Ферма» выполняет простые действия: «собирать урожай», «поливать», «окучивать», «продавать», «удобрять» и выводит их в консоль.
//Алгоритм:
//1) Создаем класс «Ферма1» (например)
//2) Создаем протоколы действий
//3) Этим протоколам задаем методы и свойства.
//4) Активируем протоколы для класса «Ферма1»
//5) Реализуем все методы и свойства протоколов в классе
//6) Выводим результаты в консоль.
//
//Например: «Протокол «Собирать урожай» активирован. И уже тут оставляйте те действия, реплики работников, которые они реализуют во время сборки урожая, как пример.*


protocol Harvest { // Собирать урожай
    var startHarvest: Bool { get }
    func harvest() -> ()
}

protocol Pour { // Поливать
    var startPour: Bool { get }
    func pour() -> ()
}

protocol Spud { // Окучивать
    var startSpud: Bool { get }
    func spud() -> ()
}

protocol ToSell { // Продавать
    var startToSell: Bool { get }
    func toSell() -> ()
}

protocol Fertilize { // Удобрять
    var startFertilize: Bool { get }
    func fertilize() -> ()
}

class Farm: Harvest, Pour, Spud, ToSell, Fertilize {

    var startHarvest: Bool = true

    func harvest() -> () {
        if startHarvest == true {
            print("Начали собирать урожай")
        } else {
            print("Урожай не собирается")
        }
    }
    
    var startPour: Bool = true

    func pour() -> () {
        if startPour == true {
            print("Начали поливать")
        } else {
            print("Не поливают")
        }
    }


    var startSpud: Bool = true

    func spud() -> () {
        if startSpud == true {
            print("Начали окучивать")
        } else {
            print("Не окучивают")
        }
    }

    var startToSell: Bool = true

    func toSell() -> () {
        if startToSell == true {
            print("Начали продавать")
        } else {
            print("Не продают")
        }
    }

    var startFertilize: Bool = true

    func fertilize() -> () {
        if startFertilize == true {
            print("Начали удобрять")
        } else {
            print("Не удобряют")
    }
    }

}

var farm = Farm()
farm.fertilize()
farm.spud()
farm.harvest()
farm.pour()
farm.toSell()

