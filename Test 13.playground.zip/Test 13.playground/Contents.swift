//Создайте псевдоним (typealias) и назовите его допустим: Tuple. Пусть этот псевдоним будет типа кортежа (Int, Int, String). Создайте
//константу типа Tuple и присвойте ей значения.

typealias Tuple = (Int, Int, String)

var a: Tuple = (1, 2, "Hi")

//Создайте любой конечный класс с двумя простыми свойствами типа Int, вычисляемым свойством, ленивым свойством, классовым свойством и
//одним методом. Инициализатор должен быть пользовательским, но не дефолтным.

class Math {
    
    var number1: Int
    var number2: Int
    var sum: Int { number1 + number2 }
    lazy var multiplication = number1 * number2
    
    func div () -> Int {
        return number1 / number2
    }
    
    init(number1: Int, number2: Int) {
        self.number1 = number1
        self.number2 = number2
    }
}

var example1 = Math (number1: 10, number2: 2)
example1.multiplication
example1.sum
example1.div()
