// ДЗ
// №1. У нас есть некоторый парент, у которого есть пара коробок, в которых могут находиться драгоценные камни.
// В каждой коробке находится по 3 камня (в массиве). Составьте три класса (структуры) точно отображающие такую ситуацию.
//
// №2. Составьте сабскрипт, который получает некоторый индекс и возвращает значеие камня в коробке, если такой индекс вообще есть,
// и который будет иметь только геттер, но не сеттер.
//
// №3. Составьте такой сабскрипт, который будет принимать два индекса, первый из которых отображает индекс коробки, а второй индекс,
// отображает номер камня в коробке. Этот сабскрипт должен иметь и геттер и сеттер. Попробуйте воспользоваться сабскриптами через
// опциональную цепочку. Задайте значение через опциональную цепочку.
//
// №4. Создайте конструкцию TimeTable, которая имеет одно свойство, которое отображает первый множитель. Составте сабскрипт который
// отображает второй множитель. То есть если мы создаем экземпляр этого класса, то он по умолчнию будет иметь один множитель,
// когда задаем сабскрипт - задаем второй множитель, таким образом мы создаем таблицу умножения на число (параметр экземпляра).
// К примеру sixTimes[5] и должно получиться 30. (Пример из руководства Apple по Swift)
//
// №5. У нас есть класс, в котором есть учительница, староста и несколько учеников (массив). Нужно составить сабскрипт, который по номеру,
// например, class[0] "Клара Захаровна", class[1] "Староста", class[2] "Иванов"... будет выдавать соответсвующего человека из класса.
// Сабскрипт должен иметь геттер и сеттер.

//---------------------------------------------------------------------------------------------------------------------------------------------

struct Boy {

    var boyBox1: Box1! = Box1()
    var boyBox2: Box2! = Box2()

    subscript (index: Int, numberBox: Int) -> String? {

        get {
            if numberBox == 1 {
                switch index {
                case 0..<boyBox1.box1.count: return boyBox1.box1[index]
                default: return nil
                }
            }
            if numberBox == 2 {
                switch index {
                case 0..<boyBox2.box2.count: return boyBox2.box2[index]
                default: return nil
                }
            }

            return nil
        }

        set {
            if numberBox == 1 {
                switch index {
                case 0..<boyBox1.box1.count : return boyBox1.box1[index] = newValue ?? ""
                default: break
                }
            }
            if numberBox == 2 {
                switch index {
                case 0..<boyBox2.box2.count : return boyBox2.box2[index] = newValue ?? ""
                default: break
                }
            }
        }
    }
}

struct Box1 {

    var box1 = ["Jewel 1", "Jewel 2", "Jewel 3"]

    subscript (index: Int) -> String? {
        get {
            switch index {
            case 0..<box1.count: return box1[index]
            default: return nil
            }
        }
    }
}

struct Box2 {

    var box2 = ["Jewel 4", "Jewel 5", "Jewel 6"]

    subscript (index: Int) -> String? {
        get {
            switch index {
            case 0..<box2.count: return box2[index]
            default: return nil
            }
        }
    }
}

var boy1 = Boy()

boy1.boyBox1.box1
boy1.boyBox1[2]
boy1.boyBox2[2]
boy1[1, 1]
boy1[1, 2]
boy1[2, 2] = "Diamond"

//---------------------------------------------------------------------------------------------------------------------------------------------
// №4. Создайте конструкцию TimeTable, которая имеет одно свойство, которое отображает первый множитель. Составте сабскрипт который
// отображает второй множитель. То есть если мы создаем экземпляр этого класса, то он по умолчнию будет иметь один множитель,
// когда задаем сабскрипт - задаем второй множитель, таким образом мы создаем таблицу умножения на число (параметр экземпляра).
// К примеру sixTimes[5] и должно получиться 30. (Пример из руководства Apple по Swift)

//class TimeTable {
//
//    var typeName: String {
//            return String(describing: TimeTable.self)
//        }
//
//    subscript (index: Int) -> Int {
//        var firstMultiplier: Int
//        switch typeName {
//           case "zeroTimes": firstMultiplier = 0
//           case "oneTimes": firstMultiplier = 1
//           case "twoTimes": firstMultiplier = 2
//           case "threeTimes": firstMultiplier = 3
//           case "fourTimes": firstMultiplier = 4
//           case "fiveTimes": firstMultiplier = 5
//           case "sixTimes": firstMultiplier = 6
//           case "sevenTimes": firstMultiplier = 7
//           case "eightTimes": firstMultiplier = 8
//           case "nineTimes": firstMultiplier = 9
//           case "tenTimes": firstMultiplier = 10
//        case "TimeTable": firstMultiplier = 100
//        default: firstMultiplier = 0
//        }
//
//        return firstMultiplier * index
//    }
//
//}

class TimeTable {
    
    let multiplier: Int
    
    subscript(index: Int) -> Int {
        return multiplier * index
    }
    
    init (multiplier: Int) {
        self.multiplier = multiplier
    }
}
 
let threeTimesTable = TimeTable(multiplier: 3)
print("шесть умножить на три будет \(threeTimesTable[6])")

//---------------------------------------------------------------------------------------------------------------------------------------------
// №5. У нас есть класс, в котором есть учительница, староста и несколько учеников (массив). Нужно составить сабскрипт, который по номеру,
// например, class[0] "Клара Захаровна", class[1] "Староста", class[2] "Иванов"... будет выдавать соответсвующего человека из класса.
// Сабскрипт должен иметь геттер и сеттер.

class Class {
    var structure = ["Клара Захаровна", "Староста", "Иванов", "Семенов", "Петров"]
    
    subscript (index: Int) -> String {
        get {
            return structure[index]
        }
        set {
            return structure[index] = newValue
        }
    }
}

var classA = Class()
classA[1]
classA[1] = "Староста Валера"
classA[1]
classA.structure
