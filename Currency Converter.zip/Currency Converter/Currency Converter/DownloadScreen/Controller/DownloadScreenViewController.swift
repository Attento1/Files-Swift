//
//  ViewController.swift
//  Currency Converter
//
//  Created by Михаил Чалков on 01.09.2022.
//

import UIKit

class DownloadScreenViewController: UIViewController {

    @IBOutlet weak var downloadButton: UIButton!
    @IBOutlet weak var goChooseCurrencyButton: UIButton!
    
    var arrayOfCurrencyName = [String]()
    var arrayOfCurrencyValue = [Double]()
    var arrayOfCurrencyConditionCode = [String]()
    var arrayOfCurrencyNominal = [Int]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        downloadButton.layer.cornerRadius = 10
        goChooseCurrencyButton.layer.cornerRadius = 10
        goChooseCurrencyButton.isHidden = true
        
        networkCurrencyDataManager.onCompletion = { [weak self] currentCurrency in
            
            self?.arrayOfCurrencyName = [currentCurrency.currencyNameCHF, currentCurrency.currencyNameCNY, currentCurrency.currencyNameEUR, currentCurrency.currencyNameGBP, currentCurrency.currencyNameUSD]
            
            self?.arrayOfCurrencyValue = [currentCurrency.valueCHF, currentCurrency.valueCNY, currentCurrency.valueEUR, currentCurrency.valueGBP, currentCurrency.valueUSD]
            
            self?.arrayOfCurrencyConditionCode = [currentCurrency.conditionCodeCHF, currentCurrency.conditionCodeCNY, currentCurrency.conditionCodeEUR, currentCurrency.conditionCodeGBP, currentCurrency.conditionCodeUSD]
            
            self?.arrayOfCurrencyNominal = [currentCurrency.currencyNominalCHF, currentCurrency.currencyNominalCNY, currentCurrency.currencyNominalEUR, currentCurrency.currencyNominalGBP, currentCurrency.currencyNominalUSD]
            
            SaveCurrencyData.saveCurrencyName = self!.arrayOfCurrencyName
            SaveCurrencyData.saveCurrencyValue = self!.arrayOfCurrencyValue
            SaveCurrencyData.saveConditionCode = self!.arrayOfCurrencyConditionCode
            SaveCurrencyData.saveCurrencyNominal = self!.arrayOfCurrencyNominal
            
            print(SaveCurrencyData.saveCurrencyName)
            print(self?.arrayOfCurrencyName as Any)
        }
        
    }
    
    var networkCurrencyDataManager = NetworkCurrencyDataManager()
    
    @IBAction func downloadButton(_ sender: UIButton) {
        
        networkCurrencyDataManager.fetchCurrentCurrency()
            
        goChooseCurrencyButton.isHidden = false
    }
        
    @IBAction func goChooseCurrencyButton(_ sender: UIButton) {
    }
    
}
