//
//  CurrentCurrency.swift
//  Currency Converter
//
//  Created by Михаил Чалков on 07.09.2022.
//

import Foundation

struct CurrentCurrency {
    let currencyNameGBP: String // Фунт стерлингов Соединенного королевства
    let valueGBP: Double
    let conditionCodeGBP: String  //id
    let currencyNominalGBP: Int
    
    
    let currencyNameUSD: String // Доллар США
    let valueUSD: Double
    let conditionCodeUSD: String  //id
    let currencyNominalUSD: Int
    
    let currencyNameEUR: String // Евро
    let valueEUR: Double
    let conditionCodeEUR: String  //id
    let currencyNominalEUR: Int
    
    let currencyNameCNY: String // Китайских юаней
    let valueCNY: Double
    let conditionCodeCNY: String  //id
    let currencyNominalCNY: Int
    
    let currencyNameCHF: String // Швейцарский франк
    let valueCHF: Double
    let conditionCodeCHF: String  //id
    let currencyNominalCHF: Int
    
    init?(currentCurrencyData: CurrentCurrencyData) {
        currencyNameGBP = currentCurrencyData.valute.gbp.name
        valueGBP = currentCurrencyData.valute.gbp.value
        conditionCodeGBP = currentCurrencyData.valute.gbp.id
        currencyNominalGBP = currentCurrencyData.valute.gbp.nominal
        
        currencyNameUSD = currentCurrencyData.valute.usd.name
        valueUSD = currentCurrencyData.valute.usd.value
        conditionCodeUSD = currentCurrencyData.valute.usd.id
        currencyNominalUSD = currentCurrencyData.valute.usd.nominal
        
        currencyNameEUR = currentCurrencyData.valute.eur.name
        valueEUR = currentCurrencyData.valute.eur.value
        conditionCodeEUR = currentCurrencyData.valute.eur.id
        currencyNominalEUR = currentCurrencyData.valute.eur.nominal
        
        currencyNameCNY = currentCurrencyData.valute.cny.name
        valueCNY = currentCurrencyData.valute.cny.value
        conditionCodeCNY = currentCurrencyData.valute.cny.id
        currencyNominalCNY = currentCurrencyData.valute.cny.nominal
        
        currencyNameCHF = currentCurrencyData.valute.chf.name
        valueCHF = currentCurrencyData.valute.chf.value
        conditionCodeCHF = currentCurrencyData.valute.chf.id
        currencyNominalCHF = currentCurrencyData.valute.chf.nominal
    }
}
