//
//  NetworkCurrencyDataManager.swift
//  Currency Converter
//
//  Created by Михаил Чалков on 03.09.2022.
//

import Foundation

class NetworkCurrencyDataManager {
    
    var onCompletion: ((CurrentCurrency) -> Void)?
    
    func fetchCurrentCurrency() {
        
        let urlString = "https://www.cbr-xml-daily.ru/daily_json.js"
        guard let url = URL(string: urlString) else { return }
        let session = URLSession(configuration: .default)
        let task = session.dataTask(with: url) { data, response, error in
            
            if let data = data {
                if let currentCurrency = self.parseJSON(withData: data) {
                    self.onCompletion?(currentCurrency)
                }
            }
        }
        task.resume()
    }
    
    func parseJSON(withData data: Data) -> CurrentCurrency? {
        let decoder = JSONDecoder()
        do {
            let currentCurrencyData = try decoder.decode(CurrentCurrencyData.self, from: data)
            guard let currentCurrency = CurrentCurrency(currentCurrencyData: currentCurrencyData) else {
                return nil
            }
            return currentCurrency
        } catch let error as NSError {
            print(error.localizedDescription)
        }
        return nil
        
    }
}
