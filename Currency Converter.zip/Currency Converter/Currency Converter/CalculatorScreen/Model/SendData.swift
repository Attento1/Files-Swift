//
//  SendData.swift
//  Currency Converter
//
//  Created by Михаил Чалков on 17.11.2022.
//

import Foundation
import UIKit

struct SendData {
    
    static var saveSendCurrencyName = ""
    static var saveSendDictionaryCurrencyValue = [String: Double]()
    static var saveSendDictionaryCurrencyNominal = [String: Int]()

}
