//
//  CalculatorScreenViewController.swift
//  Currency Converter
//
//  Created by Михаил Чалков on 24.09.2022.
//

import Foundation
import UIKit
import CoreData

class CalculatorScreenViewController: UIViewController {
    
    var uploadDataCurrencyName = ""
    var uploadDataCurrencyValue: Double = 0.0
    var uploadDataCurrencyNominal: Int = 0
    
    var uploadDictionaryCurrencyValue = SendData.saveSendDictionaryCurrencyValue
    var uploadDictionaryCurrencyNominal = SendData.saveSendDictionaryCurrencyNominal
    
    @IBOutlet weak var rublTextField: UITextField!
    @IBOutlet weak var someCurrencyTextField: UITextField!
    @IBOutlet weak var currencyLabel: UILabel!
    @IBOutlet weak var clearButton: UIButton!
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var favouritesButton: UIButton!

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        saveButton.layer.cornerRadius = 10
        favouritesButton.layer.cornerRadius = 10
        clearButton.layer.cornerRadius = 10
        
        getDataOfCurrency()
        currencyLabel.text = uploadDataCurrencyName
        
    }
    
    @IBAction func clearButton(_ sender: UIButton) {
        rublTextField.text?.removeAll()
        someCurrencyTextField.text?.removeAll()
    }
    
    
    @IBAction func saveToFavouritesButton(_ sender: UIButton) {
        let alertController = UIAlertController(title: "New Favourite", message: "Add to Favorites?", preferredStyle: .alert)
        let saveAction = UIAlertAction(title: "Add", style: .default) { action in
            self.addFavorites(withTitle: self.currencyLabel.text!)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .default) { _ in }
        
        alertController.addAction(saveAction)
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func favouritesButton(_ sender: UIButton) {
    }
    
    @IBAction func rublTextField(_ sender: UITextField) {

        someCurrencyTextField.text = String(format: "%.2f", (Double(rublTextField.text!) ?? 0) / (uploadDataCurrencyValue / Double(uploadDataCurrencyNominal)))
    }
    
    @IBAction func someCurrencyTextField(_ sender: UITextField) {
        rublTextField.text = String(format: "%.2f", (Double(someCurrencyTextField.text!) ?? 0) * (uploadDataCurrencyValue / Double(uploadDataCurrencyNominal)))
    }
    
    func getDataOfCurrency() {
        uploadDataCurrencyValue = uploadDictionaryCurrencyValue[uploadDataCurrencyName]!
        uploadDataCurrencyNominal = uploadDictionaryCurrencyNominal[uploadDataCurrencyName]!
    }
    
    private func addFavorites(withTitle title: String) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        guard let entity = NSEntityDescription.entity(forEntityName: "FavouriteCurrencyName", in: context) else { return }
        
        let taskObject = FavouriteCurrencyName(entity: entity, insertInto: context)
        taskObject.title = title
        
        do {
            try context.save()
        } catch let error as NSError {
            print(error.localizedDescription)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
}
