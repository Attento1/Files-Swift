//
//  FavouritesTableViewController.swift
//  Currency Converter
//
//  Created by Михаил Чалков on 05.10.2022.
//

import UIKit
import CoreData

class FavouritesTableViewController: UITableViewController {
    
    var currencyNames: [FavouriteCurrencyName] = []
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<FavouriteCurrencyName> = FavouriteCurrencyName.fetchRequest()
        
        do {
            currencyNames = try context.fetch(fetchRequest)
        } catch let error as NSError {
            print(error.localizedDescription)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        
        self.title = "Favourites"
        self.navigationItem.leftBarButtonItem = self.editButtonItem
        
    }
    
    @IBAction func cancelAction(_ sender: UIBarButtonItem) {
        dismiss(animated: true)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let navVC = segue.destination as? UINavigationController else {return}
        let dvc = navVC.viewControllers.first as! CalculatorScreenViewController
        let indexPath = tableView.indexPathForSelectedRow!
        
        let currencyName = currencyNames[indexPath.row]
        dvc.uploadDataCurrencyName = currencyName.title!
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return currencyNames.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        let currencyName = currencyNames[indexPath.row]
        cell.textLabel?.text = currencyName.title

        return cell
    }
    
    override func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appDelegate.persistentContainer.viewContext
            
            let currencyName = currencyNames[indexPath.row]
            context.delete(currencyName)
            
            currencyNames.remove(at: indexPath.row)
            
            do {
                
                try context.save()
                tableView.deleteRows(at: [indexPath], with: .fade)
                
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }
    }
    
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let moveCurrencyName = currencyNames.remove(at: sourceIndexPath.row)
        currencyNames.insert(moveCurrencyName, at: destinationIndexPath.row)
        tableView.reloadData()
    }

}
