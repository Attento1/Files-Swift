//
//  CurrencySelectionViewController.swift
//  Currency Converter
//
//  Created by Михаил Чалков on 14.09.2022.
//

import Foundation
import UIKit

class CurrencySelectionViewController: UIViewController {
    
    var currencyName = SaveCurrencyData.saveCurrencyName
    var currencyValue = SaveCurrencyData.saveCurrencyValue
    var conditionCode = SaveCurrencyData.saveConditionCode
    var currencyNominal = SaveCurrencyData.saveCurrencyNominal
    
    var sendDictionaryCurrencyValue = [String: Double]()
    var sendDictionaryConditionCode = [String: String]()
    var sendDictionaryCurrencyNominal = [String: Int]()
    
    var selectedElement: String?
    var sendCurrencyName = ""
    
    @IBOutlet weak var conversionButton: UIButton!
    @IBOutlet weak var currencyTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        conversionButton.layer.cornerRadius = 10
        conversionButton.isHidden = true
        
        createDictionaries()
        chooseCurrency()
        createToolbar()

    }
    
    @IBAction func conversionButton(_ sender: UIButton) {
        
    }
    
    func createDictionaries() {
        
        for item in 0..<currencyName.count {
            sendDictionaryCurrencyValue[currencyName[item]] = currencyValue[item]
            sendDictionaryConditionCode[currencyName[item]] = conditionCode[item]
            sendDictionaryCurrencyNominal[currencyName[item]] = currencyNominal[item]
        }
        
        SendData.saveSendDictionaryCurrencyValue = sendDictionaryCurrencyValue
        SendData.saveSendDictionaryCurrencyNominal = sendDictionaryCurrencyNominal
        
    }
    
    func chooseCurrency() {
        let elementPicker = UIPickerView()
        elementPicker.delegate = self

        currencyTextField.inputView = elementPicker
    }
    
    func createToolbar() {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done",
                                         style: .plain,
                                         target: self,
                                         action: #selector(dismissKeyboard))
        
        toolbar.setItems([doneButton], animated: true)
        toolbar.isUserInteractionEnabled = true
        
        currencyTextField.inputAccessoryView = toolbar
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
}

extension CurrencySelectionViewController: UIPickerViewDataSource, UIPickerViewDelegate {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return currencyName.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return currencyName[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedElement = currencyName[row]
        currencyTextField.text = selectedElement
        conversionButton.isHidden = false
        sendCurrencyName = currencyName[row]
        SendData.saveSendCurrencyName = sendCurrencyName
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let navVC = segue.destination as? UINavigationController else { return }
        let dvc = navVC.viewControllers.first as! CalculatorScreenViewController
        
        dvc.uploadDataCurrencyName = sendCurrencyName
    }
    
}
