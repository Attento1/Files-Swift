//
//  SaveCurrencyData.swift
//  Currency Converter
//
//  Created by Михаил Чалков on 02.11.2022.
//

import Foundation
import UIKit

struct SaveCurrencyData {
    
    static var saveCurrencyName = [String]()
    static var saveCurrencyValue = [Double]()
    static var saveConditionCode = [String]()
    static var saveCurrencyNominal = [Int]()
    
}
