//Задание: Предположим, что у нас есть некий текст с каким-то кол-вом слов. Все это вписано в определенное количество тетрадей по 12 страниц.
//Теперь, основываясь на конкретных цифрах примера, мы должны иметь возможность быстро вычислить кол-во требуемых тетрадей для текста.
//
//№1. Создайте класс WorkBook, которая будет иметь свойство класса maxPages = 12.
//Также создайте свойства text (количество слов в тексте), wordsOnPage (количество слов на странице) и вычисляемое свойство pages, которое
//имеет тип кортежа (Int, Int), возвращая значения деления text на wordsOnPage и второе это остаток от деления.
//
//№2. Создайте вычисляемое свойство calcWorkBookQuantity, которое точно вычисляет количество тетрадей, которое требуется для текста (т.е.
//если нам нужно 7.5 тетрадей, то это все равно 8).
//
//Также создайте функцию, которая ничего не принимает, возвращает строку. Создайте свойство lazy и присвойте ему эту функцию.
//
//№3. Создайте экземпляр, вызовите его свойство calcWorkBookQuantity, вызовите и его ленивое свойство, которому присвоена функция.



class WorkBook {
    var maxPages: Int = 12
    var text: Int
    var wordsOnPage: Int
    var maxWordsOnOneBook: Int
    var needBooksDouble: Double
    var needBooks: Double
    lazy var myLazyNothing = nothing ()
    
    
    var pages: (Int, Int) {
        return (text / wordsOnPage, text % wordsOnPage)
    }
    
    var calcWorkBookQuantity: (Double) {
        maxWordsOnOneBook = wordsOnPage * maxPages
        needBooks = Double(text / maxWordsOnOneBook)
        needBooksDouble = Double(text) / Double(maxWordsOnOneBook)
        
        if needBooks < needBooksDouble {
           needBooks = needBooks + 1
        }
        
        return (needBooks)
    }
    
    func nothing () -> String { return "string" }
    
    init (text: Int, wordsOnPage: Int) {
        self.text = text
        self.wordsOnPage = wordsOnPage
        self.maxWordsOnOneBook = wordsOnPage * maxPages
        self.needBooks = Double(text / maxWordsOnOneBook)
        self.needBooksDouble = (Double(text) / Double(maxWordsOnOneBook))
    }
}

let book1 = WorkBook (text: 263851, wordsOnPage: 250)
book1.pages
book1.calcWorkBookQuantity
book1.myLazyNothing
