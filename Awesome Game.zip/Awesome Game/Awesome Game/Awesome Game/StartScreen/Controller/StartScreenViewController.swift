//
//  ViewController.swift
//  Awesome Game
//
//  Created by Михаил Чалков on 20.04.2022.
//

import UIKit

class StartScreenViewController: UIViewController {
    
    @IBOutlet weak var StartButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        StartButton.layer.cornerRadius = 10
    }

    @IBAction func StartButton(_ sender: UIButton) {
        
    }
    
}

