//
//  ComputerGuessViewController.swift
//  Awesome Game
//
//  Created by Михаил Чалков on 31.05.2022.
//

import UIKit

class ComputerGuessViewController: UIViewController {
    
    var theHiddenNumber: String?
    var randomNumber: Int!
    var tryNumber = 1
    var numberMax = 100
    var numberMin = 0
    
    @IBOutlet weak var numberOfAttemptsLabel: UILabel!
    @IBOutlet weak var numberIsLabel: UILabel!
    @IBOutlet weak var moreButton: UIButton!
    @IBOutlet weak var equallyButton: UIButton!
    @IBOutlet weak var lessButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        randomNumber = Int.random(in: numberMin...numberMax)
        
        numberOfAttemptsLabel.text = "Try № \(tryNumber)"
        numberIsLabel.text = "Your number is-\(String(randomNumber))?"
        
        moreButton.layer.borderColor = UIColor.black.cgColor
        moreButton.layer.borderWidth = 1
        moreButton.layer.cornerRadius = 10
        
        equallyButton.layer.borderColor = UIColor.black.cgColor
        equallyButton.layer.borderWidth = 1
        equallyButton.layer.cornerRadius = 10
        
        lessButton.layer.borderColor = UIColor.black.cgColor
        lessButton.layer.borderWidth = 1
        lessButton.layer.cornerRadius = 10
    }

    @IBAction func moreButton(_ sender: UIButton) {
        
        if randomNumber == Int(theHiddenNumber!) {
            numberIsLabel.text = "Please don't lie"
        } else {
            tryNumber += 1
            numberOfAttemptsLabel.text = "Try № \(tryNumber)"
            numberMin = randomNumber + 1
            randomNumber = Int.random(in: numberMin...numberMax)
            numberIsLabel.text = "Your number is-\(String(randomNumber))?"
        }
        
    }
    
    @IBAction func equallyButton(_ sender: UIButton) {
    }
    
    @IBAction func lessButton(_ sender: UIButton) {
        if randomNumber == Int(theHiddenNumber!) {
            numberIsLabel.text = "Please don't lie"
        } else {
            tryNumber += 1
            numberOfAttemptsLabel.text = "Try № \(tryNumber)"
            numberMax = randomNumber - 1
            randomNumber = Int.random(in: numberMin...numberMax)
            numberIsLabel.text = "Your number is-\(String(randomNumber))?"
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let dvc = segue.destination as? PlayerGuessViewController else {return}
        dvc.sumComputerTry = tryNumber
    }
}
