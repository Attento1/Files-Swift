//
//  EnterScreenViewController.swift
//  Awesome Game
//
//  Created by Михаил Чалков on 23.05.2022.
//

import UIKit

class EnterScreenViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var InputWindow: UITextField!
    
    @IBOutlet weak var EnterNumberButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        InputWindow.delegate = self
        
        if InputWindow.text!.isEmpty {
            EnterNumberButton.isUserInteractionEnabled = false
            EnterNumberButton.alpha = 0.5
        }
        
        EnterNumberButton.layer.cornerRadius = 10
    }
    
    @IBAction func EnterNumberButton(_ sender: UIButton) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let dvc = segue.destination as? ComputerGuessViewController else { return }
        
        dvc.theHiddenNumber = InputWindow.text
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        EnterNumberButton.isUserInteractionEnabled = true
        EnterNumberButton.alpha = 1
        
    }
}
