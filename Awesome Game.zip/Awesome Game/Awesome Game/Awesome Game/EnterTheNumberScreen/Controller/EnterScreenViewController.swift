//
//  EnterScreenViewController.swift
//  Awesome Game
//
//  Created by Михаил Чалков on 23.05.2022.
//

import UIKit

class EnterScreenViewController: UIViewController, UITextFieldDelegate {
    
    let minValue = 0
    let maxValue = 100
    lazy var valuesRange = minValue...maxValue

    @IBOutlet weak var InputWindow: UITextField!
    
    @IBOutlet weak var EnterNumberButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        InputWindow.delegate = self
        
        if InputWindow.text!.isEmpty {
            EnterNumberButton.isUserInteractionEnabled = false
            EnterNumberButton.alpha = 0.5
        }
        
        EnterNumberButton.layer.cornerRadius = 10
    }
    
    @IBAction func EnterNumberButton(_ sender: UIButton) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let dvc = segue.destination as? ComputerGuessViewController else { return }
        
        dvc.theHiddenNumber = InputWindow.text
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if InputWindow.text!.isEmpty  {
            
            EnterNumberButton.isUserInteractionEnabled = true
            EnterNumberButton.alpha = 1
            
        } else {
            
            EnterNumberButton.isUserInteractionEnabled = false
            EnterNumberButton.alpha = 0.5
            
        }
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {

        self.view.endEditing(true)

    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let newText = NSString(string: textField.text!).replacingCharacters(in: range, with: string)
        
        if newText.isEmpty {
            
          return true
            
        }
        
        return valuesRange.contains(Int(newText) ?? minValue - 1)
        
      }
}
