//
//  PlayerGuessViewController.swift
//  Awesome Game
//
//  Created by Михаил Чалков on 11.06.2022.
//

import UIKit

class PlayerGuessViewController: UIViewController, UITextFieldDelegate {
    
    var sumComputerTry: Int?
    var randomComputerNumber: Int?
    var tryPlayerNumber = 1
    let minValue = 0
    let maxValue = 100
    lazy var valuesRange = minValue...maxValue
    
    @IBOutlet weak var tryNumberLabel: UILabel!
    @IBOutlet weak var enterAnswerField: UITextField!
    @IBOutlet weak var guessButton: UIButton!
    @IBOutlet weak var computerAnswerLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        enterAnswerField.delegate = self
        
        if enterAnswerField.text!.isEmpty {
            guessButton.isUserInteractionEnabled = false
            guessButton.alpha = 0.5
        }
        
        randomComputerNumber = Int.random(in: 0...100)
        print("\(String(describing: randomComputerNumber))")
        
        tryNumberLabel.text = "Try № \(tryPlayerNumber)"
        computerAnswerLabel.text = "It's your turn to guess"
        
        guessButton.layer.cornerRadius = 10
        
    }
    
    @IBAction func enterAnswer(_ sender: UIButton) {
        
        if String(enterAnswerField.text!) == String(randomComputerNumber!) {
            guard let LastScreenViewController = self.storyboard?.instantiateViewController(withIdentifier: "LastScreenViewController") as? LastScreenViewController else {return}
            
            LastScreenViewController.playerTryCount = tryPlayerNumber
            LastScreenViewController.computerTryCount = sumComputerTry

            self.present(LastScreenViewController, animated: true, completion: nil)
            
            
            
        } else if String(enterAnswerField.text!) > String(randomComputerNumber!) {
            tryPlayerNumber += 1
            tryNumberLabel.text = "Try № \(tryPlayerNumber)"
            enterAnswerField.text = ""
            computerAnswerLabel.text = "No, my number is less than yours"
            
        } else if String(enterAnswerField.text!) < String(randomComputerNumber!) {
            tryPlayerNumber += 1
            tryNumberLabel.text = "Try № \(tryPlayerNumber)"
            enterAnswerField.text = ""
            computerAnswerLabel.text = "No, my number is more than yours"
        }
        
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        guessButton.isUserInteractionEnabled = true
        guessButton.alpha = 1
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let newText = NSString(string: textField.text!).replacingCharacters(in: range, with: string)
        
        if newText.isEmpty {
          return true
        }
        
        return valuesRange.contains(Int(newText) ?? minValue - 1)
        
      }
    
}
