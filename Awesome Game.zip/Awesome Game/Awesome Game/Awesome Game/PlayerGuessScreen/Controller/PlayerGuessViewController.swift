//
//  PlayerGuessViewController.swift
//  Awesome Game
//
//  Created by Михаил Чалков on 11.06.2022.
//

import UIKit

class PlayerGuessViewController: UIViewController {
    
    var sumComputerTry: Int?
    var randomComputerNumber: Int?
    var tryPlayerNumber = 1
    
    @IBOutlet weak var tryNumberLabel: UILabel!
    @IBOutlet weak var enterAnswerField: UITextField!
    @IBOutlet weak var guessButton: UIButton!
    @IBOutlet weak var computerAnswerLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        randomComputerNumber = Int.random(in: 0...100)
        print("\(String(describing: randomComputerNumber))")
        
        tryNumberLabel.text = "Try № \(tryPlayerNumber)"
        computerAnswerLabel.text = "It's your turn to guess"
        
        guessButton.layer.cornerRadius = 10
        
    }
    
    @IBAction func enterAnswer(_ sender: UIButton) {
        
        if String(enterAnswerField.text!) == String(randomComputerNumber!) {
            guard let LastScreenViewController = self.storyboard?.instantiateViewController(withIdentifier: "LastScreenViewController") as? LastScreenViewController else {return}
            
            LastScreenViewController.playerTryCount = tryPlayerNumber
            LastScreenViewController.computerTryCount = sumComputerTry

            self.present(LastScreenViewController, animated: true, completion: nil)
            
            
            
        } else if String(enterAnswerField.text!) > String(randomComputerNumber!) {
            tryPlayerNumber += 1
            tryNumberLabel.text = "Try № \(tryPlayerNumber)"
            enterAnswerField.text = ""
            computerAnswerLabel.text = "No, my number is less than yours"
            
        } else if String(enterAnswerField.text!) < String(randomComputerNumber!) {
            tryPlayerNumber += 1
            tryNumberLabel.text = "Try № \(tryPlayerNumber)"
            enterAnswerField.text = ""
            computerAnswerLabel.text = "No, my number is more than yours"
        }
        
    }
    
}
