//
//  LastScreenViewController.swift
//  Awesome Game
//
//  Created by Михаил Чалков on 12.06.2022.
//

import UIKit

class LastScreenViewController: UIViewController {
    
    var playerTryCount: Int!
    var computerTryCount: Int!
    
    @IBOutlet weak var playerTryCountLabel: UILabel!
    @IBOutlet weak var computerTryCountLabel: UILabel!
    @IBOutlet weak var whoWinnerLabel: UILabel!
    @IBOutlet weak var mainMenuButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        mainMenuButton.layer.cornerRadius = 10
        
        guard let playerTryCount = self.playerTryCount else { return }
        playerTryCountLabel.text = "Your's tries count: \(String(describing: playerTryCount))"
        
        guard let computerTryCount = self.computerTryCount else { return }
        computerTryCountLabel.text = "Computer's tries count: \(String(describing: computerTryCount))"
        
        if playerTryCount == computerTryCount {
            whoWinnerLabel.text = "No one won"
        } else if playerTryCount > computerTryCount {
            whoWinnerLabel.text = "Computer Win"
        } else if playerTryCount < computerTryCount {
            whoWinnerLabel.text = "You Win"
        }
    }
    
    @IBAction func goMainMenu(_ sender: UIButton) {
    }
    
}
