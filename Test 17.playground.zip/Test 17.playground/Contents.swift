//Придумайте любую цепочку зависящих друг от друга действий, как это было представлено в видео. Напишите опциональную последовательность
//и то же самое решение через инструкцию guard.

class Car {
    var year: Year? = Year()
    var seats: Seats? = Seats()
    var carPlay: CarPlay? = CarPlay()
    
}

struct Year {
    var year = 2019
        
}

struct Seats {
    var seats = "Black"
    
}

struct CarPlay {
    var carPlay = true
    
}

let ferrari = Car()

ferrari.year?.year
ferrari.seats?.seats
ferrari.carPlay?.carPlay

var year = 2019
var seats = "Black"
var carPlay = true

func test (a: Int, b: String, c: Bool) {
    
    guard a != 2019, b != "Black", c != true else {
        print ("\(a)")
        print ("\(b)")
        print ("\(c)")
        return
    }
}

test(a: year, b: "Black", c: true)
