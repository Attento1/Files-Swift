//У нас есть пациент, который лежит в больнице (inHospital = true) и принимает по 5 таблеток в день, ему запрещено заниматься спортом. Но как
//только он выписывается из больницы, то ему можно заниматься спортом и не пить таблетки. А так же у него есть свойство storyAboutHospital,
//которая равна пустой строке пока он не выпишется. Однако при выписке у него появляется, что рассказать друзьям.
//
//Запишите метод, который рассказывает storyAboutHospital.


class Pacient {
    
    var tabletInDay = 5
    var playingSport = false
    var storyAboutHospital = "......"
    var inHospital = true {
       
        didSet {

            if inHospital == false {
                print("Пациент выписался")
                tabletInDay = 0
                print("Необходимо принимать \(tabletInDay) таблеток")
                playingSport = true
                storyAboutHospital = "Big story..."
            } else {
                print("Пациент в больнице")
                tabletInDay = 5
                print("Необходимо принимать \(tabletInDay) таблеток")
                playingSport = false
                storyAboutHospital = "No story..."
            }
            
            if playingSport == true {
                print("Можно заниматься спортом")
            } else {
                print("Нельзя заниматься спортом")
            }
        }
    }
    
    func tellStory() -> () {
        print("\(storyAboutHospital)")
    }
}

var pacient1 = Pacient ()
pacient1.inHospital = false
pacient1.tabletInDay
pacient1.tellStory()
