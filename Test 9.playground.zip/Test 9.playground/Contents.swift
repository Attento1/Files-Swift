//К дополнению к заданию в прошлом тесте в класс Student добавить еще одно свойство fullname: String, которое будет вычисляться на основании
//параметров name и surname. У любого объекта этого класса вызвать это свойство и вывести результат на экран.


class Student {
var name : String
var surname : String
var yearOfBorn : Int
var mark : Double
var fullname : String
    
init(name: String, surname : String, yearOfBorn : Int, mark : Double) {
    self.name = name
    self.surname = surname
    self.yearOfBorn = yearOfBorn
    self.mark = mark
    self.fullname = self.name + " " + self.surname
    }
    func printParam(_: Student) -> () {
        print("Name is: \(name)")
        print("Surname is: \(surname)")
        print("Year of born is: \(yearOfBorn)")
        print("Mark is: \(mark)")
    }
}

let Student1 = Student(name: "John", surname: "Jonson", yearOfBorn: 1995, mark: 4.5)
let Student2 = Student(name: "Alex", surname: "Alexson", yearOfBorn: 2000, mark: 5)
let Student3 = Student(name: "Peter", surname: "Romanoff", yearOfBorn: 1996, mark: 4.7)
let Student4 = Student(name: "Sam", surname: "Gemsdgi", yearOfBorn: 1994, mark: 4.8)

Student1.fullname
Student2.fullname
Student3.fullname
Student4.fullname
