//Ниже представлен класс, в теле этого класса создайте функцию, которая будет распечатывать параметры
//данного класса по конкретному объекту. Создайте такой объект класса Student, вызовите у него эту функцию и
//выведите результат на экран.

class Student {
var name : String
var surname : String
var yearOfBorn : Int
var mark : Double
init(name: String, surname : String, yearOfBorn : Int, mark : Double) {
    self.name = name
    self.surname = surname
    self.yearOfBorn = yearOfBorn
    self.mark = mark
    }
    func printParam(_: Student) -> () {
        print("Name is: \(name)")
        print("Surname is: \(surname)")
        print("Year of born is: \(yearOfBorn)")
        print("Mark is: \(mark)")
    }
}

let Student1 = Student(name: "John", surname: "Jonson", yearOfBorn: 1995, mark: 4.5)
let Student2 = Student(name: "Alex", surname: "Alexson", yearOfBorn: 2000, mark: 5)
//Student2.printParam(Student2)

//К дополнению к первому заданию, создайте 4 объекта типа Student, поместите их в массив и
//отсортируйте по свойству mark по возрастанию. Выведите полученный результат на экран.

let Student3 = Student(name: "Peter", surname: "Romanoff", yearOfBorn: 1996, mark: 4.7)
let Student4 = Student(name: "Sam", surname: "Gemsdgi", yearOfBorn: 1994, mark: 4.8)

var allStudentMark = [Student1.mark, Student2.mark, Student3.mark, Student4.mark]

repeat {

    var saveNumber: Double

    for element in 1 ... 3 {

        if allStudentMark[0] > allStudentMark[element] {

            saveNumber = allStudentMark[0]
            allStudentMark[0] = allStudentMark[element]
            allStudentMark[element] = saveNumber

        }

    }

    for element in 2 ... 3 {

        if allStudentMark[1] > allStudentMark[element] {

            saveNumber = allStudentMark[1]
            allStudentMark[1] = allStudentMark[element]
            allStudentMark[element] = saveNumber

        }

    }

    if allStudentMark[2] > allStudentMark[3] {

        saveNumber = allStudentMark[2]
        allStudentMark[2] = allStudentMark[3]
        allStudentMark[3] = saveNumber
    }

} while allStudentMark[0] > allStudentMark[1] || allStudentMark[1] > allStudentMark[2] || allStudentMark[2] > allStudentMark[3]

allStudentMark

//var count = 0
//
//repeat {
//
//    repeat {
//
//       for element in count ... 3 {
//
//           if allStudentMark[count] > allStudentMark[element] {
//
//               allStudentMark.append(allStudentMark[count])
//               allStudentMark.remove(at: count)
//
//           }
//
//       }
//    } while allStudentMark[count] > allStudentMark[count + 1] || allStudentMark[count] > allStudentMark[2] || allStudentMark[count] > allStudentMark[3]
//
//    count += 1
//
//} while allStudentMark[0] > allStudentMark[1] || allStudentMark[1] > allStudentMark[2] || allStudentMark[2] > allStudentMark[3]
//
//allStudentMark

var allStudentInfo = [Student1, Student2, Student3, Student4]

Student1.mark

for number in 0 ... 3 {
    
    switch allStudentMark[number] {
    case Student1.mark:
        
        allStudentInfo[number] = Student1
        
    case Student2.mark:
        
        allStudentInfo[number] = Student2
        
    case Student3.mark:
        
        allStudentInfo[number] = Student3
        
    case Student4.mark:
        
        allStudentInfo[number] = Student4
    default:
        print("No matches")
    }
}

allStudentInfo
