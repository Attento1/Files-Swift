import UIKit
//You are asked to square every digit of a number and concatenate them.

//For example, if we run 9119 through the function, 811181 will come out, because 92 is 81 and 12 is 1.

//Note: The function accepts an integer and returns an integer

func squareDigits(_ num: Int) -> Int {
    let intToStr = String(num)
    var finNumber = 0
    var finNumberToString = ""

    for item in intToStr {
        let itemToStr = String(item)
        let itemToInt = Int(itemToStr)
        let square = itemToInt! * itemToInt!
        let squareToString = String(square)
        finNumberToString += squareToString
    }
    
    finNumber = Int(finNumberToString)!
    
  return finNumber
}

squareDigits(12345)
